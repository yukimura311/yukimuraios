#include "ogg_wav_bridge.h"
#include <stdlib.h>
#include <string.h>

#if __has_include("stb_vorbis.c")
#define STB_VORBIS_NO_PUSHDATA_API
#define STB_VORBIS_NO_STDIO
#include "stb_vorbis.c"
#define HAS_STB_VORBIS 1
#else
#define HAS_STB_VORBIS 0
#endif

static void write_le32(uint8_t* p, uint32_t v) {
    p[0] = (uint8_t)(v & 0xFF);
    p[1] = (uint8_t)((v >> 8) & 0xFF);
    p[2] = (uint8_t)((v >> 16) & 0xFF);
    p[3] = (uint8_t)((v >> 24) & 0xFF);
}

static void write_le16(uint8_t* p, uint16_t v) {
    p[0] = (uint8_t)(v & 0xFF);
    p[1] = (uint8_t)((v >> 8) & 0xFF);
}

uint8_t* piofiore_decode_ogg_to_wav(const uint8_t* ogg_data, size_t ogg_len, size_t* out_wav_len) {
    if (!ogg_data || ogg_len == 0 || !out_wav_len) return NULL;
    *out_wav_len = 0;
#if HAS_STB_VORBIS
    int channels = 0;
    int sample_rate = 0;
    short* pcm_output = NULL;
    int samples = stb_vorbis_decode_memory(ogg_data, (int)ogg_len, &channels, &sample_rate, &pcm_output);
    if (samples <= 0 || !pcm_output || channels <= 0 || sample_rate <= 0) {
        if (pcm_output) free(pcm_output);
        return NULL;
    }
    uint32_t pcm_bytes = (uint32_t)samples * (uint32_t)channels * 2u;
    uint32_t wav_total = 44u + pcm_bytes;
    uint8_t* wav = (uint8_t*)malloc(wav_total);
    if (!wav) {
        free(pcm_output);
        return NULL;
    }
    memcpy(wav + 0, "RIFF", 4);
    write_le32(wav + 4, wav_total - 8u);
    memcpy(wav + 8, "WAVEfmt ", 8);
    write_le32(wav + 16, 16u);
    write_le16(wav + 20, 1u); // PCM
    write_le16(wav + 22, (uint16_t)channels);
    write_le32(wav + 24, (uint32_t)sample_rate);
    write_le32(wav + 28, (uint32_t)(sample_rate * channels * 2));
    write_le16(wav + 32, (uint16_t)(channels * 2));
    write_le16(wav + 34, 16u);
    memcpy(wav + 36, "data", 4);
    write_le32(wav + 40, pcm_bytes);
    memcpy(wav + 44, pcm_output, pcm_bytes);
    free(pcm_output);
    *out_wav_len = (size_t)wav_total;
    return wav;
#else
    return NULL;
#endif
}
