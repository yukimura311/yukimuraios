import UIKit
import WebKit
import UniformTypeIdentifiers

class GameViewController: UIViewController, WKScriptMessageHandler, UIDocumentPickerDelegate {

    private var webView: WKWebView!

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.setURLSchemeHandler(AssetSchemeHandler.shared, forURLScheme: "piofiore")

        let contentController = WKUserContentController()
        contentController.add(self, name: "nativeBridge")
        config.userContentController = contentController

        webView = WKWebView(frame: view.bounds, configuration: config)
        webView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.scrollView.backgroundColor = .black
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.bounces = false
        if #available(iOS 11.0, *) {
            webView.scrollView.contentInsetAdjustmentBehavior = .never
        }
        view.addSubview(webView)

        if let startURL = URL(string: "piofiore://app/index.html") {
            webView.load(URLRequest(url: startURL))
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "nativeBridge",
              let body = message.body as? [String: Any],
              let action = body["action"] as? String else { return }

        if action == "pickAssetsFolder" {
            presentAssetsFolderPicker()
        } else if action == "checkStatus" {
            notifyAssetsStatus()
        }
    }

    private func presentAssetsFolderPicker() {
        let picker: UIDocumentPickerViewController
        if #available(iOS 14.0, *) {
            picker = UIDocumentPickerViewController(forOpeningContentTypes: [.folder], asCopy: false)
        } else {
            picker = UIDocumentPickerViewController(documentTypes: ["public.folder"], in: .open)
        }
        picker.delegate = self
        picker.allowsMultipleSelection = false
        picker.modalPresentationStyle = .formSheet
        present(picker, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let folderURL = urls.first else { return }
        AssetSchemeHandler.shared.saveMountedFolderURL(folderURL)
        notifyAssetsStatus()
    }

    private func notifyAssetsStatus() {
        let status = AssetSchemeHandler.shared.checkAssetsStatus()
        if let data = try? JSONSerialization.data(withJSONObject: status),
           let jsonStr = String(data: data, encoding: .utf8) {
            webView.evaluateJavaScript("window.onNativeAssetsStatus && window.onNativeAssetsStatus(\(jsonStr));", completionHandler: nil)
        }
    }
}
