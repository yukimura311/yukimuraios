



S_Product = {
	data = {},
	size = 0,
}


product = {}

function product.all_get(e, param)
	return S_Product.data
end

function product.size_get(e, param)
	local size = S_Product.size
	
	if(param.ret ~= nil)then
		e:tag{ "var", name = param.ret, data = size }
	end
	return size
end

function product.set(e, param)
	local name = param.name
	
	if(S_Product.data[name] ~= nil)then
		return
	end
	
	S_Product.data[name] = {
		name = name,
		index = S_Product.size,
		id = param.id,
		title = param.title,
		price = nil,
	}
	
	S_Product.size = S_Product.size + 1
end

function product.get(e, param)
	local name = param.name
	local index = tonumber(param.index)
	local id = param.id
	
	local info
	
	if(index ~= nil)then
		for key, value in pairs(product.all_get(e))do
			if(value.index == index)then
				info = value
				break
			end
		end
	elseif(id ~= nil)then
		for key, value in pairs(product.all_get(e))do
			if(value.id == id)then
				info = value
				break
			end
		end
	else
		info = S_Product.data[name]
	end
	
	if(info == nil)then
		return nil
	end
	
	if(param.ret ~= nil)then
		local var_name = param.ret
		e:tag{ "var", name = var_name, system = "delete" }
		e:tag{ "var", name = var_name..".index", data = tostring(info.index) }
		e:tag{ "var", name = var_name..".id", data = info.id }
		e:tag{ "var", name = var_name..".title", data = info.title }
		e:tag{ "var", name = var_name..".price", data = tostring(info.price) }
	end
	
	return info
end

function product.update(e, param)
	local name = param.name
	local info = product.get(e, { name = name })
	
	if(info == nil)then
		return
	end
	
	if(param.title ~= nil)then
		info.title = param.title
	end
	if(param.price ~= nil)then
		info.price = param.price
	end
end

function product.purchased_set(e, param)
	local name = param.name
	local info = product.get(e, { name = name })
	local flag = (tostring(param.purchased) == "true")
	
	if(info == nil)then
		return nil
	end
	
	local var_name = string.format("g.product.%s.purchased", name)
	e:tag{ "var", name = obfuscate_var_name(e, { var_name = var_name }), data = tostring(flag) }
end

function product.purchased_get(e, param)
	if(param.ret ~= nil)then
		e:tag{ "var", name = param.ret, data = "true" }
	end
	return true
end
function product.purchased_get_orig(e, param)
	local name = param.name
	local info = product.get(e, { name = name })
	
	if(info == nil)then
		return nil
	end
	
	local var_name = string.format("g.product.%s.purchased", name)
	local flag = (e:var(obfuscate_var_name(e, { var_name = var_name })) == "true")
	
	if(param.ret ~= nil)then
		e:tag{ "var", name = param.ret, data = tostring(flag) }
	end
	return flag
end

function product.purchased_reset(e)
	for key, value in pairs(product.all_get(e))do
		product.purchased_set(e, { name = value.name, purchased = false })
	end
end


purchase = {}

purchase.RET_CODE = {
	OK				= 0,	
	PURCHASED		= 1,	
	RESTORED		= 2,	
	NOT_PURCHASED	= 3,	
	
	RESTRICTED		= -1,	
	NETWORK_OFFLINE	= -2,	
	INVALID_PRODUCT	= -3,	
	UNKNOWN			= -10,	
	CLIENT_ERROR	= -11,	
	CANCELED		= -12,	
	PARAMS_ERROR	= -13,	
	PAYMENT_ERROR	= -14,	
	CONNECT_ERROR	= -21,	
}

if(OS == OS_ANDROID)then
	function purchase.license_key_get(e, param)
		local ret = "t.ret"
		e:tag{ "callnative", module = "com/karakurism/BootIniReader", method = "getPublicKey", param = "", result = ret }
		return e:var(ret)
	end
end

function purchase.info_get(e, param)
	local info = product.get(e, { name = param.name, index = param.index })
	local var_name = (param.ret ~= nil) and param.ret or "t.ret"
	
	if(info == nil)then
		e:tag{ "var", name = var_name, data = -10000 }
		return
	end
	
	if(OS == OS_WINDOWS)then
		e:enqueueTag{ "var", name = var_name, data = purchase.RET_CODE.NOT_PURCHASED }
		e:enqueueTag{ "var", name = var_name..".title", data = info.title }
		e:enqueueTag{ "var", name = var_name..".price", data = "￥2,800" }
		e:enqueueTag{ "tag", data = "calllua,function,purchase.info_get_result,name,"..info.name..",result,"..var_name }
	elseif(OS == OS_IOS)then
		e:enqueueTag{ "purchase", productid = info.id, varname = var_name, purchase = 0 }
		e:enqueueTag{ "tag", data = "calllua,function,purchase.info_get_result,name,"..info.name..",result,"..var_name }
	elseif(OS == OS_ANDROID)then
		local key = purchase.license_key_get(e)
		e:enqueueTag{ "purchase", key = key, sku = info.id, varname = var_name, purchase = 0 }
		e:enqueueTag{ "tag", data = "calllua,function,purchase.info_get_result,name,"..info.name..",result,"..var_name }
	end
end
function purchase.info_get_result(e, param)
	local name = param.name
	
	local var_name = param.result
	local ret_code = tonumber(e:var(var_name))
	
	
	if(ret_code >= purchase.RET_CODE.OK)then
		local title = e:var(var_name..".title")
		local price = e:var(var_name..".price")
		product.update(e, { name = name, title = title, price = price })
	end
end

function purchase.exec(e, param)
	local info = product.get(e, { name = param.name })
	local var_name = (param.ret ~= nil) and param.ret or "t.ret"
	
	if(info == nil)then
		e:tag{ "var", name = var_name, data = -10000 }
		return
	end
	
	if(OS == OS_WINDOWS)then
		e:enqueueTag{ "var", name = var_name, data = purchase.RET_CODE.PURCHASED }
		e:enqueueTag{ "tag", data = "calllua,function,purchase.exec_result,name,"..info.name..",result,"..var_name }
	elseif(OS == OS_IOS)then
		e:enqueueTag{ "purchase", productid = info.id, varname = var_name, purchase = 1 }
		e:enqueueTag{ "tag", data = "calllua,function,purchase.exec_result,name,"..info.name..",result,"..var_name }
	elseif(OS == OS_ANDROID)then
		local key = purchase.license_key_get(e)
		e:enqueueTag{ "purchase", key = key, sku = info.id, varname = var_name, purchase = 1 }
		e:enqueueTag{ "tag", data = "calllua,function,purchase.exec_result,name,"..info.name..",result,"..var_name }
	end
end
function purchase.exec_result(e, param)
	local name = param.name
	
	local var_name = param.result
	local ret_code = tonumber(e:var(var_name))
	
	
	if(ret_code >= purchase.RET_CODE.OK)then
		product.purchased_set(e, { name = name, purchased = true })
	end
end

function purchase.restore(e, param)
	local var_name = (param.ret ~= nil) and param.ret or "t.ret"
	
	if(OS == OS_WINDOWS)then
		local info = product.get(e, { index = param.index })
		if(info ~= nil)then
			e:enqueueTag{ "var", name = var_name, data = purchase.RET_CODE.RESTORED }
			e:enqueueTag{ "tag", data = "calllua,function,purchase.restore_result,name,"..info.name..",result,"..var_name }
		end
	elseif(OS == OS_IOS)then
		e:enqueueTag{ "purchase", varname = var_name, restore = 1 }
		e:enqueueTag{ "tag", data = "calllua,function,purchase.restore_ios_result,result,"..var_name }
	elseif(OS == OS_ANDROID)then
		local info = product.get(e, { index = param.index })
		if(info ~= nil)then
			local key = purchase.license_key_get(e)
			e:enqueueTag{ "purchase", key = key, sku = info.id, varname = var_name, purchase = 0 }
			e:enqueueTag{ "tag", data = "calllua,function,purchase.restore_result,name,"..info.name..",result,"..var_name }
		end
	end
end
function purchase.restore_result(e, param)
	local name = param.name
	
	local var_name = param.result
	local ret_code = tonumber(e:var(var_name))
	
	
	if(ret_code >= purchase.RET_CODE.OK)then
		local flag = false
		if(ret_code == purchase.RET_CODE.RESTORED)then
			flag = true
		end
		product.purchased_set(e, { name = name, purchased = flag })
	end
end
function purchase.restore_ios_result(e, param)
	local var_name = param.result
	local ret_code = tonumber(e:var(var_name))
	
	
	if(ret_code >= purchase.RET_CODE.OK)then
		product.purchased_reset(e)
		
		local restored_product = {}
		
		local restored_size = tonumber(e:var(var_name..".size"))
		for i = 1, restored_size do
			local id = e:var(var_name.."."..(i - 1))
			table.insert(restored_product, id)
		end
		
		for i = 1, #restored_product do
			local info = product.get(e, { id = restored_product[i] })
			if(info ~= nil)then
				product.purchased_set(e, { name = info.name, purchased = true })
			end
		end
	end
end



