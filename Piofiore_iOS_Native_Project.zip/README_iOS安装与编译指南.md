# 《虔诚之花的晚钟 -ricordo-》iOS 原生移植工程 (`PiofioreIOS`)

本工程基于你提供的安卓汉化版配置文件（`system.ini`、`main.iet`、`system.zip` 以及 `100.iet`/`101.iet`/`150.iet`）逆向还原构建，采用 **轻量级原生 iOS 引擎包（`.ipa` 仅约 2 MB）+ 手机本地直读 2.04 GB `assets` 文件夹** 的架构设计。

---

## 一、 核心特性

1. **100% 原生立绘拼合与坐标还原**：
   - 完整内嵌 `system/init/2_ichara.lua` 中的 **373 组角色身体底图（如 `b-dan_a10`）与表情差分（如 `b-dan_a100a`）像素级坐标偏移表**，自动在 1280×720 画布上合成角色立绘。
2. **原生 C 语言 Ogg Vorbis -> PCM WAV 音频解码桥接（`ogg_wav_bridge.c`）**：
   - 针对原包中全部为 `.ogg` 格式的 **19,319 条角色语音（`voice_ogg`）**、**48 首背景音乐（`bgm_ogg`）** 与 **音效（`se_ogg`）**，通过内置 C 解码器实时转换为 iOS 原生 PCM 音频流播放，无需手动转换任何音频文件。
3. **完整还原《虔诚之花的晚钟》专属系统**：
   - **MS 系统（Meanwhile Story 视角切换）**：完整内嵌 `dbMsSystem.lua` 的 166 个视角切换事件，触发 `[msicon_on_pf]` 时自动弹出视角切换按钮，看完支线视角后自动返回主线原位置。
   - **好感度与路线分支判定**：完整实现 `[feel_up]`、`[feel2_up]`、`[flag_cmp]` 好感度比对与个人线（但丁 / 吉尔伯特 / 杨 / 尼古拉 / 奥罗克 / 终曲 / After Story）自动分流。
   - **全章节直达、20 槽位存档/读档、快速存读档、带语音重播的历史记录（Backlog）、布鲁罗纳词典（89 词条）**。
4. **免上传 2GB 大文件、免大包签名卡死**：
   - 编译生成的 `Piofiore_Ricordo_iOS.ipa` 体积仅约 2 MB，使用 Sideloadly / AltStore / TrollStore 几秒钟即可完成签名安装。
   - 安装后直接在 iPhone 自带的「文件」App 中挂载你已经解压好的 2.04 GB `assets` 文件夹即可游玩。

---

## 二、 如何免 Mac 编译生成 `.ipa` 并安装到 iPhone / iPad

### 第一步：用 GitHub Actions 免费云端自动编译 `.ipa`（无需 Mac 电脑）
1. 在 GitHub 上新建一个仓库（Repository，设为 Public 或 Private 均可）。
2. 将本压缩包解压后的所有文件（确保包含 `.github/workflows/build-ipa.yml`、`PiofioreIOS.xcodeproj` 和 `PiofioreIOS` 文件夹）上传并提交到仓库。
3. 点击仓库顶部的 **Actions** 标签页，等待约 1～2 分钟，`Build Piofiore Native iOS IPA` 工作流会自动在云端 macOS 虚拟机中拉取 `stb_vorbis.c` 并通过 Xcode 编译打包。
4. 构建完成后，在任务底部的 **Artifacts** 区域点击下载 **`Piofiore_Ricordo_iOS_IPA`**，解压即可拿到 **`Piofiore_Ricordo_iOS.ipa`**。
   *(注：如果你手头有 Mac 电脑，也可以直接双击 `PiofioreIOS.xcodeproj` 用 Xcode 连接手机真机一键安装)*

### 第二步：将 `.ipa` 签名安装到 iPhone / iPad
- **普通未越狱设备**：在电脑上使用 **Sideloadly**、**AltStore** 或 **爱思助手（Apple ID 签名）**，导入 `Piofiore_Ricordo_iOS.ipa` 并输入你的免费 Apple ID 即可在几秒钟内安装到手机桌面（首次安装后在手机「设置 -> 通用 -> VPN 与设备管理」中信任证书）。
- **巨魔（TrollStore）设备**：直接在手机上用 TrollStore 打开 `Piofiore_Ricordo_iOS.ipa` 即可永久安装。

### 第三步：在手机上挂载你已解压的 2.04 GB `assets` 文件夹（二选一）
- **方法 A（推荐，免移动文件）**：打开桌面上安装好的 **《虔诚之花的晚钟》** App，点击标题界面上的 **「📂 选择手机中的 assets 文件夹」**，在弹出的 iOS 原生文件选择器中直接选中你之前解压好的 `虔诚之花的晚钟/assets` 文件夹，点击「打开」即可永久授权直读。
- **方法 B（放入应用专属目录）**：打开 iPhone 自带的 **「文件」** App -> 进入 **「我的 iPhone -> 虔诚之花的晚钟」**，把你解压出来的 **`assets` 文件夹**直接移动到该目录下，重新打开游戏即可自动识别。

---

## 三、 附赠：基于日区官方 App Store 原生底包的汉化补丁（`Official_iOS_IPA_Patch/`）

如果你拥有日区 App Store 官方原版《ピオフィオーレの晩鐘 -ricordo-》（Bundle ID: `jp.co.ideaf.pfnssmp`）的砸壳 `.ipa` 包，本压缩包内的 `Official_iOS_IPA_Patch/` 目录还为你准备了专门修正过 iOS 音频路径与内购解锁的 `init_proc.iet` 和 `purchase.lua`：
1. 将本包 `Official_iOS_IPA_Patch/system/` 下的 `init_proc.iet` 和 `purchase.lua` 覆盖进你的安卓 `assets/system/` 目录；
2. 将整个 `assets/` 内的文件替换进官方 iOS `.ipa` 的 `Payload/ricordo.app/` 资源目录中，重新签名安装即可直接运行官方原版二进制引擎。
