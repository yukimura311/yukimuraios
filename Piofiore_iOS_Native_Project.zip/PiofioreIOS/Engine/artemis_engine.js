/**
 * Artemis Engine (.iet / Lua) Native iOS Interpreter for 《虔诚之花的晚钟 -ricordo-》
 * Supports:
 * - Full composite character sprite rendering (base body + face overlay via 2_ichara.lua coordinates)
 * - Full .iet tag & label parser (*sureN, [if]/[elseif]/[else]/[/if], [flag_set], [flag_cmp], [feel_up])
 * - MS (Meanwhile Story) side-perspective popup & return stack
 * - Local iPhone `assets` folder mounting via WKURLSchemeHandler (`piofiore://assets/...`) or Web File API
 */

const Engine = (() => {
  const DB = window.PIOFIORE_DB;
  const SCR_W = 1280;
  const SCR_H = 720;

  // Virtual File System for Web Folder Picker fallback
  const localFileMap = new Map();
  let nativeAssetsMounted = false;

  // Game Runtime State
  let state = {
    file: "100",
    label: "sure80",
    pc: 0,
    speaker: "",
    textLines: [],
    bg: "bg_BLACK",
    timeTint: "NOON",
    bgm: "",
    loopSe: "",
    charas: {}, // slotKey -> { ch_name, pt_name, em_name, place, zpos }
    flags: Object.assign({}, DB.initFlags.normal),
    spFlags: Object.assign({}, DB.initFlags.system),
    vars: {
      "i": 0, "j": 0, "k": 0, "AX": 0, "BX": 0, "CX": 0,
      "g.debug_mode": 0,
      "S_Proc.spt.file": "100",
      "S_Proc.spt.thread": "sure80",
      "Name1": "莉莉安娜",
      "Name2": "亚多尔纳特",
      "Name3": "莉莉"
    },
    msActive: null,   // { no, text, file, sure, compel }
    msReturnStack: null, // { file, label, pc, bg, charas }
    saveTitle: "Prologue",
    backlog: []
  };

  let parsedScripts = {}; // fileNo -> { lines: [], labels: {} }
  let pendingChoices = [];
  let waitingForClick = false;
  let waitingForChoice = false;
  let waitingForMovie = false;
  let autoMode = false;
  let skipMode = false;
  let autoTimer = null;
  let skipTimer = null;

  // Audio players
  const bgmAudio = new Audio();
  bgmAudio.loop = true;
  const voiceAudio = new Audio();
  const seAudio = new Audio();
  const imageCache = new Map();

  // Scale 1280x720 stage to fit iPhone/iPad screen cleanly
  function resizeStage() {
    const wrapper = document.getElementById("stage-wrapper");
    const scaleX = window.innerWidth / SCR_W;
    const scaleY = window.innerHeight / SCR_H;
    const scale = Math.min(scaleX, scaleY);
    wrapper.style.transform = `scale(${scale})`;
  }
  window.addEventListener("resize", resizeStage);
  window.addEventListener("orientationchange", () => setTimeout(resizeStage, 100));

  // Resolve asset URL (checks Web File Map first, then native piofiore://assets/ scheme)
  async function resolveAssetURL(relPath) {
    const clean = relPath.replace(/^\/+/, "").replace(/^assets\//, "");
    const lower = clean.toLowerCase();
    if (localFileMap.has(lower)) {
      const fileObj = localFileMap.get(lower);
      return URL.createObjectURL(fileObj);
    }
    return `piofiore://assets/${clean}`;
  }

  async function fetchTextAsset(relPath) {
    const clean = relPath.replace(/^\/+/, "").replace(/^assets\//, "");
    const lower = clean.toLowerCase();
    if (localFileMap.has(lower)) {
      const fileObj = localFileMap.get(lower);
      return await fileObj.text();
    }
    try {
      const resp = await fetch(`piofiore://assets/${clean}`);
      if (resp.ok) {
        return await resp.text();
      }
    } catch (e) {}
    return null;
  }

  // Parse .iet script into structured tokens & labels
  function parseIetScript(rawText) {
    const lines = [];
    const labels = {};
    const rawLines = rawText.replace(/\r\n/g, "\n").split("\n");
    let inBlockComment = false;

    for (let raw of rawLines) {
      let line = raw.trim();
      if (!line) continue;
      if (line.startsWith("/*")) {
        if (!line.includes("*/")) inBlockComment = true;
        continue;
      }
      if (inBlockComment) {
        if (line.includes("*/")) inBlockComment = false;
        continue;
      }
      if (line.startsWith("//") || line.startsWith(";")) continue;

      if (line.startsWith("*")) {
        const labelName = line.substring(1).trim().split(/\s+/)[0];
        labels[labelName] = lines.length;
        lines.push({ type: "label", name: labelName });
        continue;
      }

      // Extract all [tag attr="val"] on the same line
      const tagRegex = /\[(\/?[a-zA-Z0-9_]+)(.*?)\]/g;
      let match;
      while ((match = tagRegex.exec(line)) !== null) {
        const tagName = match[1];
        const attrStr = match[2] || "";
        const attrs = {};
        const attrRegex = /([a-zA-Z0-9_]+)\s*=\s*"([^"]*)"/g;
        let am;
        while ((am = attrRegex.exec(attrStr)) !== null) {
          attrs[am[1]] = am[2];
        }
        lines.push({ type: "tag", tag: tagName, attrs });
      }
    }
    return { lines, labels };
  }

  async function loadScenarioFile(fileNo) {
    const key = String(fileNo).replace(/\.iet$/i, "");
    if (parsedScripts[key]) return parsedScripts[key];

    // 1. Try loading from mounted local assets/scenario/<key>.iet
    let text = await fetchTextAsset(`scenario/${key}.iet`);
    // 2. Fallback to built-in scenarios (100, 101, 150)
    if (!text && DB.builtinScenarios && DB.builtinScenarios[key]) {
      text = DB.builtinScenarios[key];
    }
    if (!text) {
      return null;
    }
    parsedScripts[key] = parseIetScript(text);
    return parsedScripts[key];
  }

  // Variable & Flag helpers
  function resolveVal(valStr) {
    if (valStr === undefined || valStr === null) return "";
    let s = String(valStr).trim();
    if (s.startsWith("$")) {
      const vName = s.substring(1).trim();
      if (vName.startsWith("t.define.")) {
        const defKey = vName.replace("t.define.", "");
        return DB.stcmDefine[defKey] !== undefined ? DB.stcmDefine[defKey] : defKey;
      }
      if (state.vars[vName] !== undefined) return state.vars[vName];
      if (state.flags[vName] !== undefined) return state.flags[vName];
      if (DB.stcmDefine[vName] !== undefined) return DB.stcmDefine[vName];
      return 0;
    }
    if (DB.stcmDefine[s] !== undefined) return DB.stcmDefine[s];
    if (/^-?\d+$/.test(s)) return parseInt(s, 10);
    return s;
  }

  function evalEstimate(expr) {
    if (!expr) return false;
    let e = expr.trim();
    if (e.startsWith("$")) e = e.substring(1);

    // Replace t.define.XYZ and variable names
    e = e.replace(/t\.define\.([A-Za-z0-9_]+)/g, (_, k) => {
      return DB.stcmDefine[k] !== undefined ? DB.stcmDefine[k] : 0;
    });
    e = e.replace(/\$([A-Za-z0-9_.]+)/g, (_, k) => {
      if (state.vars[k] !== undefined) return JSON.stringify(state.vars[k]);
      if (state.flags[k] !== undefined) return state.flags[k];
      return 0;
    });
    e = e.replace(/\b([A-Za-z_][A-Za-z0-9_.]*)\b/g, (token) => {
      if (["true", "false", "null"].includes(token)) return token;
      if (DB.stcmDefine[token] !== undefined) return DB.stcmDefine[token];
      if (state.vars[token] !== undefined) {
        const v = state.vars[token];
        return typeof v === "number" ? v : `"${v}"`;
      }
      if (state.flags[token] !== undefined) return state.flags[token];
      return 0;
    });
    try {
      return Boolean(Function(`"use strict"; return (${e});`)());
    } catch (err) {
      return false;
    }
  }

  function formatDialogueText(raw) {
    if (!raw) return "";
    return raw
      .replace(/#Name\[1\]/g, state.vars.Name1 || "莉莉安娜")
      .replace(/#Name\[2\]/g, state.vars.Name2 || "亚多尔纳特")
      .replace(/#Name\[3\]/g, state.vars.Name3 || "莉莉")
      .replace(/#n/g, "\n")
      .replace(/\[[^\]]*\]/g, "");
  }

  // Visual Rendering: Background + Time Tint
  async function updateBackground(bgName, timeMode) {
    if (bgName) state.bg = bgName;
    if (timeMode) state.timeTint = timeMode;

    const bgEl = document.getElementById("bg-layer");
    if (!state.bg || state.bg === "bg_BLACK" || state.bg === "NO_BG") {
      bgEl.style.backgroundImage = "none";
      bgEl.style.backgroundColor = "#050406";
      return;
    }
    if (state.bg === "bg_WHITE") {
      bgEl.style.backgroundImage = "none";
      bgEl.style.backgroundColor = "#f5f5f5";
      return;
    }

    // Try .jpg then .png in image/back/
    const jpgUrl = await resolveAssetURL(`image/back/${state.bg}.jpg`);
    const pngUrl = await resolveAssetURL(`image/back/${state.bg}.png`);
    bgEl.style.backgroundImage = `url("${jpgUrl}"), url("${pngUrl}")`;

    // Apply time-of-day filter
    const t = String(state.timeTint);
    if (t === "NIGHT" || t === "2") {
      bgEl.style.filter = "brightness(0.78) saturate(0.88) hue-rotate(8deg)";
    } else if (t === "EV" || t === "EV2" || t === "1") {
      bgEl.style.filter = "sepia(0.28) brightness(0.92) saturate(1.15)";
    } else if (t === "SEPIA") {
      bgEl.style.filter = "sepia(0.75) brightness(0.9)";
    } else {
      bgEl.style.filter = "none";
    }
  }

  // Load an Image object with caching
  function loadImageCached(relPath) {
    if (imageCache.has(relPath)) return imageCache.get(relPath);
    const p = new Promise(async (resolve) => {
      const urlPng = await resolveAssetURL(`${relPath}.png`);
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => resolve(img);
      img.onerror = async () => {
        const urlJpg = await resolveAssetURL(`${relPath}.jpg`);
        const img2 = new Image();
        img2.crossOrigin = "anonymous";
        img2.onload = () => resolve(img2);
        img2.onerror = () => resolve(null);
        img2.src = urlJpg;
      };
      img.src = urlPng;
    });
    imageCache.set(relPath, p);
    return p;
  }

  // Compute horizontal X center from `chara_place_select` in DF_function.lua
  function getPlaceCenterX(placeVal) {
    const p = resolveVal(placeVal);
    let divNum = 3, divPos = 1;
    const D = DB.stcmDefine;
    if (p === D.LEFT || placeVal === "LEFT") { divNum = 9; divPos = 2; }
    else if (p === D.CENTER || placeVal === "CENTER") { divNum = 3; divPos = 1; }
    else if (p === D.RIGHT || placeVal === "RIGHT") { divNum = 9; divPos = 6; }
    else if (p === D.HI_RIGHT || placeVal === "HI_RIGHT") { divNum = 9; divPos = 7; }
    else if (p === D.HI_LEFT || placeVal === "HI_LEFT") { divNum = 9; divPos = 1; }
    else if (p === D.MD_RIGHT || placeVal === "MD_RIGHT") { divNum = 7; divPos = 4; }
    else if (p === D.MD_LEFT || placeVal === "MD_LEFT") { divNum = 7; divPos = 2; }
    else if (p === D.MD_RIGHT2 || placeVal === "MD_RIGHT2") { divNum = 6; divPos = 3; }
    else if (p === D.MD_LEFT2 || placeVal === "MD_LEFT2") { divNum = 6; divPos = 2; }
    return (SCR_W / divNum) * divPos + (SCR_W / divNum) / 2;
  }

  // Exact implementation of `strfdel` in DF_function.lua:
  // Given full `emName` e.g. `b-dan_a100a` or `mar_a100a`:
  // slotName = del 4 chars from end -> `b-dan_a` / `mar_a`
  // ptName   = del 3 chars from end + "0" -> `b-dan_a10` / `mar_a10`
  function splitCharaName(fullChName) {
    const s = String(fullChName || "").trim();
    if (s.length <= 4) return { slotName: s, ptName: s, emName: s };
    const slotName = s.substring(0, s.length - 4);
    const ptName = s.substring(0, s.length - 3) + "0";
    return { slotName, ptName, emName: s };
  }

  // Render all active character sprites onto #chara-stage using 2_ichara.lua coordinates
  async function renderCharacters() {
    const stage = document.getElementById("chara-stage");
    stage.innerHTML = "";

    const entries = Object.values(state.charas);
    for (const ch of entries) {
      const ptn = DB.charaInfo[ch.ptName];
      const bodyImg = await loadImageCached(`image/chara/${ptn ? ptn.gp_name : ch.ptName}`);
      const faceImg = await loadImageCached(`image/chara/${ch.emName}`);

      if (!bodyImg && !faceImg) continue;

      const slotDiv = document.createElement("div");
      slotDiv.className = "chara-slot";

      const canvas = document.createElement("canvas");
      canvas.className = "chara-canvas";
      const bw = bodyImg ? bodyImg.naturalWidth : (ptn ? Math.round(ptn.src_w * 4 / 3) : 1024);
      const bh = bodyImg ? bodyImg.naturalHeight : (ptn ? Math.round(ptn.src_h * 4 / 3) : 1024);
      canvas.width = bw;
      canvas.height = bh;

      const ctx = canvas.getContext("2d");
      if (bodyImg) {
        ctx.drawImage(bodyImg, 0, 0);
      }
      if (faceImg && ptn && ptn.face) {
        ctx.drawImage(faceImg, ptn.face[0], ptn.face[1]);
      } else if (faceImg && !bodyImg) {
        ctx.drawImage(faceImg, 0, 0);
      }

      // Position calculation matching AD_CharaPatternGet in adv_gpchara.lua
      let posX = (SCR_W - bw) / 2;
      let posY = SCR_H - bh;
      if (ptn) {
        const adjX = (SCR_W - Math.floor(ptn.src_w * 4 / 3 + 0.5)) / 2;
        const adjY = SCR_H - Math.floor(ptn.src_h * 4 / 3 + 0.5);
        const centerX = Math.floor(ptn.cx * 4 / 3 + 0.5);
        const centerY = Math.floor(ptn.cy * 4 / 3 + 0.5);
        const cutX = ptn.src_x === 0 ? 0 : Math.floor(ptn.src_x * 4 / 3 + 0.5);
        posX = adjX + centerX + cutX;
        posY = adjY + centerY;
      }

      const placeOffsetX = getPlaceCenterX(ch.place) - (SCR_W / 2);
      canvas.style.left = `${Math.round(posX + placeOffsetX)}px`;
      canvas.style.top = `${Math.round(posY)}px`;

      slotDiv.appendChild(canvas);
      stage.appendChild(slotDiv);
    }
  }

  // Audio playback helpers
  async function playBGM(no) {
    const key = String(no).padStart(2, "0");
    if (state.bgm === key) return;
    state.bgm = key;
    const infoFile = (DB.mediaInfo.bgm && DB.mediaInfo.bgm[key]) ? DB.mediaInfo.bgm[key] : `${key}_a`;
    bgmAudio.src = await resolveAssetURL(`sound/bgm_ogg/${infoFile}.ogg`);
    bgmAudio.volume = 0.55;
    bgmAudio.play().catch(() => {});
  }

  function stopBGM() {
    state.bgm = "";
    bgmAudio.pause();
  }

  async function playVoice(no) {
    if (!no || String(no) === "0") return;
    const vFile = String(no).trim();
    voiceAudio.src = await resolveAssetURL(`sound/voice_ogg/${vFile}.ogg`);
    voiceAudio.volume = 0.95;
    voiceAudio.play().catch(() => {});
  }

  async function playSE(no) {
    if (!no || String(no) === "0") return;
    const sFile = String(no).trim().padStart(5, "0");
    seAudio.src = await resolveAssetURL(`sound/se_ogg/${sFile}.ogg`);
    seAudio.volume = 0.75;
    seAudio.play().catch(() => {});
  }

  async function playMovie(movieKey) {
    const fileBase = (DB.mediaInfo.movie && DB.mediaInfo.movie[movieKey]) ? DB.mediaInfo.movie[movieKey] : movieKey.toLowerCase();
    const overlay = document.getElementById("movie-overlay");
    const video = document.getElementById("movie-player");
    const url = await resolveAssetURL(`movie/${fileBase}.mp4`);

    return new Promise((resolve) => {
      waitingForMovie = true;
      overlay.style.display = "flex";
      video.src = url;
      const finish = () => {
        if (!waitingForMovie) return;
        waitingForMovie = false;
        video.pause();
        video.removeAttribute("src");
        overlay.style.display = "none";
        resolve();
      };
      video.onended = finish;
      video.onerror = finish;
      video.play().catch(finish);
    });
  }

  function skipMovie() {
    if (!waitingForMovie) return;
    const video = document.getElementById("movie-player");
    if (video.onended) video.onended();
  }

  // Execute scenario loop until a batch display / choice / jump occurs
  async function stepScenario() {
    if (waitingForChoice || waitingForMovie) return;
    waitingForClick = false;

    let script = await loadScenarioFile(state.file);
    if (!script) {
      renderDialogueBox("系统提示", `未找到剧本文件 scenario/${state.file}.iet。\n请先在标题界面点击「📂 选择手机中的 assets 文件夹」或将解压的 assets 文件夹放入「我的 iPhone -> 虔诚之花的晚钟」目录。`);
      return;
    }

    document.getElementById("hud-chapter-label").textContent = `${state.saveTitle || "Story"} · ${state.file}.iet`;

    let maxSteps = 2500;
    let ifSkipDepth = 0;
    let ifMatchedStack = [];

    while (state.pc < script.lines.length && maxSteps-- > 0) {
      const item = script.lines[state.pc++];
      if (item.type === "label") continue;

      const { tag, attrs } = item;

      // Conditional block handling ([if], [elseif], [else], [/if])
      if (tag === "if") {
        if (ifSkipDepth > 0) {
          ifSkipDepth++;
        } else {
          const cond = evalEstimate(attrs.estimate);
          ifMatchedStack.push(cond);
          if (!cond) ifSkipDepth = 1;
        }
        continue;
      }
      if (tag === "elseif") {
        if (ifSkipDepth === 1 && ifMatchedStack.length > 0 && !ifMatchedStack[ifMatchedStack.length - 1]) {
          const cond = evalEstimate(attrs.estimate);
          if (cond) {
            ifMatchedStack[ifMatchedStack.length - 1] = true;
            ifSkipDepth = 0;
          }
        } else if (ifSkipDepth === 0) {
          ifSkipDepth = 1;
        }
        continue;
      }
      if (tag === "else") {
        if (ifSkipDepth === 1 && ifMatchedStack.length > 0 && !ifMatchedStack[ifMatchedStack.length - 1]) {
          ifMatchedStack[ifMatchedStack.length - 1] = true;
          ifSkipDepth = 0;
        } else if (ifSkipDepth === 0) {
          ifSkipDepth = 1;
        }
        continue;
      }
      if (tag === "/if") {
        if (ifSkipDepth > 0) {
          ifSkipDepth--;
        }
        if (ifSkipDepth === 0 && ifMatchedStack.length > 0) {
          ifMatchedStack.pop();
        }
        continue;
      }
      if (ifSkipDepth > 0) continue;

      // Variable & Flag operations
      if (tag === "var") {
        const val = resolveVal(attrs.data);
        state.vars[attrs.name] = val;
        continue;
      }
      if (tag === "flag_set" || tag === "flag_make") {
        state.flags[attrs.name] = Number(resolveVal(attrs.num)) || 0;
        continue;
      }
      if (tag === "flag_change") {
        const cur = Number(state.flags[attrs.name] || 0);
        state.flags[attrs.name] = cur + (Number(resolveVal(attrs.num)) || 0);
        continue;
      }
      if (tag === "flag_number") {
        const val = state.flags[attrs.name] !== undefined ? state.flags[attrs.name] : 0;
        state.vars[attrs.i] = val;
        continue;
      }
      if (tag === "spflag_set" || tag === "spflag_make") {
        state.spFlags[attrs.name] = Number(resolveVal(attrs.num)) || 0;
        continue;
      }
      if (tag === "spflag_change") {
        const cur = Number(state.spFlags[attrs.name] || 0);
        state.spFlags[attrs.name] = cur + (Number(resolveVal(attrs.num)) || 0);
        continue;
      }
      if (tag === "spflag_number") {
        const val = state.spFlags[attrs.name] !== undefined ? state.spFlags[attrs.name] : 0;
        state.vars[attrs.i] = val;
        continue;
      }

      // Affection macros from adv_macro_pf.iet
      if (tag === "feel_reset") {
        state.flags["好感度_ダンテ"] = 0;
        state.flags["好感度_ギルバート"] = 0;
        state.flags["好感度_楊"] = 0;
        state.flags["好感度_ニコラ"] = 0;
        state.flags["好感度_オルロック"] = 0;
        state.flags["好感度_アンリ"] = 0;
        state.flags["サブパラメータ"] = 0;
        continue;
      }
      if (tag === "feel_up") {
        const ch = attrs.ch_name;
        const delta = Number(resolveVal(attrs.num)) || 1;
        const map = {
          "ID_DAN": "好感度_ダンテ",
          "ID_GIL": "好感度_ギルバート",
          "ID_YAN": "好感度_楊",
          "ID_NIC": "好感度_ニコラ",
          "ID_ORL": "好感度_オルロック",
          "ID_HEN": "好感度_アンリ"
        };
        if (map[ch]) {
          state.flags[map[ch]] = (state.flags[map[ch]] || 0) + delta;
        }
        continue;
      }
      if (tag === "feel2_up") {
        const delta = Number(resolveVal(attrs.num)) || 1;
        state.flags["サブパラメータ"] = (state.flags["サブパラメータ"] || 0) + delta;
        continue;
      }
      if (tag === "flag_cmp") {
        const names = [attrs.name1, attrs.name2, attrs.name3, attrs.name4, attrs.name5];
        let bestIdx = 0;
        let maxVal = -1;
        names.forEach((n, idx) => {
          if (n && state.flags[n] !== undefined && state.flags[n] > maxVal) {
            maxVal = state.flags[n];
            bestIdx = idx;
          }
        });
        state.vars[attrs.i || "j"] = bestIdx;
        continue;
      }

      // Label / Thread / File Jumps
      if (tag === "calllua" && attrs.function === "stcm2_goto") {
        const target = attrs.label;
        if (script.labels[target] !== undefined) {
          state.pc = script.labels[target];
          ifSkipDepth = 0;
          ifMatchedStack = [];
        }
        continue;
      }
      if (tag === "thread_change") {
        state.label = attrs.label;
        state.vars["S_Proc.spt.thread"] = attrs.label;
        continue;
      }
      if (tag === "file_change") {
        const nextFile = String(attrs.no);
        const nextLabel = attrs.label || "sure1";
        if (nextFile === "800") {
          // Scene play return
          showTitleScreen();
          return;
        }
        state.file = nextFile;
        state.label = nextLabel;
        state.flags["switch"] = 0;
        script = await loadScenarioFile(state.file);
        if (!script) {
          renderDialogueBox("系统提示", `已到达剧本跳转点：scenario/${state.file}.iet (${state.label})。\n挂载完整 2GB assets 文件夹后即可无缝继续后续章节！`);
          return;
        }
        state.pc = script.labels[state.label] || 0;
        ifSkipDepth = 0;
        ifMatchedStack = [];
        continue;
      }
      if (tag === "return") {
        // In Artemis STCM2 mainloop, [return] re-enters current S_Proc.spt.file at S_Proc.spt.thread
        const targetLabel = state.label;
        if (script.labels[targetLabel] !== undefined) {
          state.pc = script.labels[targetLabel];
          ifSkipDepth = 0;
          ifMatchedStack = [];
          continue;
        }
        break;
      }

      // Save point title
      if (tag === "save_name") {
        state.saveTitle = (attrs.name || "").replace(/　/g, " ");
        document.getElementById("hud-chapter-label").textContent = `${state.saveTitle} · ${state.file}.iet`;
        continue;
      }

      // Backgrounds & Scene Changes
      if (["ezbg_change", "ezbg_change2", "ezbg_change3", "ezbg_change4", "ezbg_change_pf", "bg_print_change"].includes(tag)) {
        await updateBackground(attrs.name, attrs.time);
        continue;
      }
      if (["scenechange_bs", "scenechange_pf", "scenechange_cameraset", "scenechange_cameraset2"].includes(tag)) {
        state.charas = {};
        await renderCharacters();
        await updateBackground(attrs.bg_name, attrs.time);
        continue;
      }
      if (tag === "scenechange_mssystem_pf") {
        state.charas = {};
        await renderCharacters();
        await updateBackground(attrs.bg, attrs.time);
        continue;
      }
      if (tag === "title_start") {
        state.charas = {};
        await renderCharacters();
        if (attrs.bg) await updateBackground(attrs.bg, attrs.nTime);
        continue;
      }
      if (tag === "blackout_start" || tag === "blackout_start2") {
        const fx = document.getElementById("screen-fx");
        fx.style.background = attrs.color === "F_WHITE" ? "#fff" : "#000";
        fx.style.opacity = "1";
        continue;
      }
      if (tag === "blackout_end" || tag === "blackout_end2") {
        const fx = document.getElementById("screen-fx");
        fx.style.opacity = "0";
        continue;
      }

      // Character Sprite Appearance / Expression Change / Movement / Deletion
      if (["chara_app_pf", "chara_app_pf_tc", "chara_app_pf_tc2", "chara_app_all"].includes(tag)) {
        const { slotName, ptName, emName } = splitCharaName(attrs.ch_name);
        state.charas[slotName] = {
          slotName, ptName, emName,
          place: attrs.place || "CENTER",
          zpos: attrs.zpos || "ZPOS_BACK3"
        };
        await renderCharacters();
        continue;
      }
      if (tag === "ezchara_nextstate2" || tag === "ezchara_nextstate") {
        const { slotName, ptName, emName } = splitCharaName(attrs.ch_name);
        const existing = state.charas[slotName] || { place: "CENTER" };
        state.charas[slotName] = {
          slotName, ptName, emName,
          place: existing.place,
          zpos: attrs.zpos || existing.zpos || "ZPOS_BACK3"
        };
        await renderCharacters();
        continue;
      }
      if (tag === "ezchara_move_pf" || tag === "ezchara_move2") {
        const slotName = attrs.ch_name;
        if (state.charas[slotName]) {
          state.charas[slotName].place = attrs.place || "CENTER";
          await renderCharacters();
        }
        continue;
      }
      if (["ezchara_del_pf", "ezchara_del_pf_tc", "ezchara_del_pf_tc2", "ezchara_del"].includes(tag)) {
        delete state.charas[attrs.ch_name];
        await renderCharacters();
        continue;
      }
      if (tag === "ezchara_del_all_pf" || tag === "ezchara_del_all") {
        state.charas = {};
        await renderCharacters();
        continue;
      }

      // Audio & Movie tags
      if (tag === "bgm_play") {
        playBGM(attrs.no);
        continue;
      }
      if (tag === "bgm_stop") {
        stopBGM();
        continue;
      }
      if (tag === "voice_play") {
        state.lastVoice = attrs.no;
        playVoice(attrs.no);
        continue;
      }
      if (tag === "se_play2" || tag === "se_play3" || tag === "strse_play") {
        playSE(attrs.no);
        continue;
      }
      if (tag === "movie_play") {
        await playMovie(attrs.name);
        continue;
      }

      // MS (Meanwhile Story) System
      if (tag === "msicon_on_pf") {
        const msNo = String(resolveVal(attrs.num));
        const msInfo = DB.msSystem[msNo];
        if (msInfo) {
          state.msActive = msInfo;
          const msBtn = document.getElementById("ms-popup");
          document.getElementById("ms-popup-title").textContent = `《${msInfo.text}》`;
          msBtn.style.display = "block";
        }
        continue;
      }
      if (tag === "msicon_off_pf") {
        state.msActive = null;
        document.getElementById("ms-popup").style.display = "none";
        continue;
      }
      if (tag === "return_ui_mssystem_pf") {
        if (state.msReturnStack) {
          const ret = state.msReturnStack;
          state.msReturnStack = null;
          state.file = ret.file;
          state.label = ret.label;
          state.pc = ret.pc;
          state.charas = ret.charas;
          await updateBackground(ret.bg, ret.timeTint);
          await renderCharacters();
          script = await loadScenarioFile(state.file);
          continue;
        }
        continue;
      }

      // Speaker & Text Accumulation
      if (tag === "speaker_change" || tag === "speaker_change_pf") {
        state.speaker = formatDialogueText(attrs.name || "");
        continue;
      }
      if (tag === "maintxt_print2" || tag === "maintxt_print") {
        if (attrs.text) {
          state.textLines.push(formatDialogueText(attrs.text));
        }
        continue;
      }
      if (["default_txt_print", "default_txt_print1", "default_txt_print2", "default_txt_print3", "default_txt_print_1_2", "default_txt_print_2_3"].includes(tag)) {
        if (attrs.no1 && attrs.no1 !== "0") {
          state.lastVoice = attrs.no1;
          playVoice(attrs.no1);
        }
        if (attrs.text1) state.textLines.push(formatDialogueText(attrs.text1));
        if (attrs.text2 && ["default_txt_print", "default_txt_print2", "default_txt_print3", "default_txt_print_2_3"].includes(tag)) {
          state.textLines.push(formatDialogueText(attrs.text2));
        }
        if (attrs.text3 && ["default_txt_print", "default_txt_print3"].includes(tag)) {
          state.textLines.push(formatDialogueText(attrs.text3));
        }
        continue;
      }

      // Interactive Menu Choices
      if (tag === "menutxt_set" || tag === "menutxt_set2") {
        pendingChoices.push({
          id: attrs.id || attrs.num || pendingChoices.length,
          text: formatDialogueText(attrs.text || ""),
          file: String(attrs.file || state.file),
          sure: attrs.sure
        });
        continue;
      }
      if (tag === "menutxt_set_flag") {
        const flagVal = state.flags[attrs.flag] || 0;
        if (flagVal !== 0) {
          pendingChoices.push({
            id: attrs.nId || pendingChoices.length,
            text: formatDialogueText(attrs.text || ""),
            file: String(attrs.file || state.file),
            sure: attrs.sure
          });
        }
        continue;
      }

      // Batch synchronization point: display accumulated text or choices
      if (tag === "batch" || tag === "batch_pf") {
        if (pendingChoices.length > 0) {
          if (state.textLines.length > 0) {
            const fullText = state.textLines.join("\n");
            state.textLines = [];
            renderDialogueBox(state.speaker, fullText);
          }
          presentChoices(pendingChoices.slice());
          pendingChoices = [];
          return;
        }
        if (state.textLines.length > 0) {
          const fullText = state.textLines.join("\n");
          state.textLines = [];
          renderDialogueBox(state.speaker, fullText);
          state.backlog.push({
            speaker: state.speaker,
            text: fullText,
            voice: state.lastVoice || null
          });
          if (state.backlog.length > 120) state.backlog.shift();
          state.lastVoice = null;
          state.speaker = "";
          waitingForClick = true;
          scheduleAutoOrSkip();
          return;
        }
      }
    }
  }

  function renderDialogueBox(speaker, text) {
    const spEl = document.getElementById("speaker-tag");
    const txtEl = document.getElementById("dialogue-text");
    if (speaker && speaker.trim()) {
      spEl.style.display = "block";
      spEl.textContent = speaker;
    } else {
      spEl.style.display = "none";
    }
    txtEl.textContent = text;
  }

  function presentChoices(choices) {
    waitingForChoice = true;
    const overlay = document.getElementById("choice-overlay");
    overlay.innerHTML = "";
    overlay.style.display = "flex";

    choices.forEach((ch, idx) => {
      const btn = document.createElement("button");
      btn.className = "choice-btn";
      btn.textContent = ch.text;
      btn.onclick = async (e) => {
        e.stopPropagation();
        overlay.style.display = "none";
        waitingForChoice = false;
        state.flags["select"] = idx;
        state.flags["switch"] = 0;
        state.file = String(ch.file);
        state.label = ch.sure;
        const sc = await loadScenarioFile(state.file);
        if (sc && sc.labels[state.label] !== undefined) {
          state.pc = sc.labels[state.label];
        } else {
          state.pc = 0;
        }
        stepScenario();
      };
      overlay.appendChild(btn);
    });
  }

  async function triggerMsScene() {
    if (!state.msActive) return;
    const ms = state.msActive;
    state.msActive = null;
    document.getElementById("ms-popup").style.display = "none";

    // Push return state so [return_ui_mssystem_pf] resumes seamlessly
    state.msReturnStack = {
      file: state.file,
      label: state.label,
      pc: state.pc,
      bg: state.bg,
      timeTint: state.timeTint,
      charas: JSON.parse(JSON.stringify(state.charas))
    };

    state.file = String(ms.file);
    state.label = ms.sure;
    state.flags["switch"] = 0;
    const sc = await loadScenarioFile(state.file);
    if (sc && sc.labels[state.label] !== undefined) {
      state.pc = sc.labels[state.label];
    } else {
      state.pc = 0;
    }
    stepScenario();
  }

  function scheduleAutoOrSkip() {
    clearTimeout(autoTimer);
    clearTimeout(skipTimer);
    if (skipMode && waitingForClick && !waitingForChoice) {
      skipTimer = setTimeout(() => {
        if (waitingForClick) stepScenario();
      }, 90);
    } else if (autoMode && waitingForClick && !waitingForChoice) {
      autoTimer = setTimeout(() => {
        if (waitingForClick) stepScenario();
      }, 2400);
    }
  }

  function onStageClick() {
    if (waitingForChoice || waitingForMovie) return;
    if (waitingForClick) {
      stepScenario();
    }
  }

  function toggleAuto() {
    autoMode = !autoMode;
    if (autoMode) skipMode = false;
    document.getElementById("btn-auto").classList.toggle("active", autoMode);
    document.getElementById("btn-skip").classList.toggle("active", false);
    scheduleAutoOrSkip();
  }

  function toggleSkip() {
    skipMode = !skipMode;
    if (skipMode) autoMode = false;
    document.getElementById("btn-skip").classList.toggle("active", skipMode);
    document.getElementById("btn-auto").classList.toggle("active", false);
    scheduleAutoOrSkip();
  }

  // Start / Jump / Save / Load
  async function jumpToScenario(fileNo, labelName) {
    closeModal();
    document.getElementById("title-screen").style.display = "none";
    state.file = String(fileNo);
    state.label = labelName || "sure1";
    state.flags["switch"] = 0;
    state.textLines = [];
    state.charas = {};
    await renderCharacters();
    const sc = await loadScenarioFile(state.file);
    if (sc && sc.labels[state.label] !== undefined) {
      state.pc = sc.labels[state.label];
    } else {
      state.pc = 0;
    }
    stepScenario();
  }

  function startNewGame() {
    state.flags = Object.assign({}, DB.initFlags.normal);
    jumpToScenario("100", "sure80");
  }

  function continueGame() {
    const q = localStorage.getItem("piofiore_save_quick") || localStorage.getItem("piofiore_save_1");
    if (q) {
      loadSaveData(JSON.parse(q));
    } else {
      startNewGame();
    }
  }

  function createSaveSnapshot() {
    return {
      timestamp: new Date().toLocaleString("zh-CN"),
      file: state.file,
      label: state.label,
      pc: Math.max(0, state.pc - 1),
      saveTitle: state.saveTitle,
      speaker: document.getElementById("speaker-tag").textContent || "",
      lastText: document.getElementById("dialogue-text").textContent || "",
      bg: state.bg,
      timeTint: state.timeTint,
      bgm: state.bgm,
      charas: state.charas,
      flags: state.flags,
      spFlags: state.spFlags,
      vars: state.vars
    };
  }

  async function loadSaveData(snap) {
    closeModal();
    document.getElementById("title-screen").style.display = "none";
    state.file = snap.file;
    state.label = snap.label;
    state.pc = snap.pc || 0;
    state.saveTitle = snap.saveTitle || "Saved Game";
    state.bg = snap.bg || "bg_BLACK";
    state.timeTint = snap.timeTint || "NOON";
    state.charas = snap.charas || {};
    state.flags = Object.assign({}, DB.initFlags.normal, snap.flags || {});
    state.spFlags = Object.assign({}, DB.initFlags.system, snap.spFlags || {});
    state.vars = Object.assign({}, state.vars, snap.vars || {});
    await updateBackground(state.bg, state.timeTint);
    await renderCharacters();
    if (snap.bgm) playBGM(snap.bgm);
    renderDialogueBox(snap.speaker, snap.lastText);
    waitingForClick = true;
  }

  function quickSave() {
    const snap = createSaveSnapshot();
    localStorage.setItem("piofiore_save_quick", JSON.stringify(snap));
    alert("快速存档成功！");
  }

  function quickLoad() {
    const raw = localStorage.getItem("piofiore_save_quick");
    if (!raw) {
      alert("暂无快速存档记录。");
      return;
    }
    loadSaveData(JSON.parse(raw));
  }

  function showTitleScreen() {
    stopBGM();
    document.getElementById("title-screen").style.display = "flex";
  }

  // Modal Screens
  function openModal(type) {
    const modal = document.getElementById("modal-container");
    const titleEl = document.getElementById("modal-title-text");
    const bodyEl = document.getElementById("modal-body-content");
    bodyEl.innerHTML = "";
    modal.style.display = "flex";

    if (type === "save") {
      titleEl.textContent = "存档与读档管理 (Save & Load - 20 Slots)";
      const grid = document.createElement("div");
      grid.className = "grid-2";
      for (let i = 1; i <= 20; i++) {
        const key = `piofiore_save_${i}`;
        const raw = localStorage.getItem(key);
        const snap = raw ? JSON.parse(raw) : null;
        const card = document.createElement("div");
        card.className = "item-card";
        card.innerHTML = `
          <div class="item-card-title">SLOT ${String(i).padStart(2, "0")} — ${snap ? snap.saveTitle + " (" + snap.file + ".iet)" : "【空存档位】"}</div>
          <div class="item-card-desc">${snap ? snap.timestamp + "\n" + (snap.speaker ? snap.speaker + "：" : "") + snap.lastText.slice(0, 42) : "点击下方按钮保存当前进度"}</div>
          <div style="display:flex;gap:10px;margin-top:6px;">
            <button class="ctrl-btn" onclick="event.stopPropagation();Engine.saveToSlot(${i})">写入存档</button>
            ${snap ? `<button class="ctrl-btn" onclick="event.stopPropagation();Engine.loadFromSlot(${i})">读取进度</button>` : ""}
          </div>
        `;
        grid.appendChild(card);
      }
      bodyEl.appendChild(grid);
    } else if (type === "backlog") {
      titleEl.textContent = "剧情对话回看 (Backlog & Voice Replay)";
      if (state.backlog.length === 0) {
        bodyEl.innerHTML = `<div class="item-card-desc">暂无已读对话记录。</div>`;
      } else {
        state.backlog.slice().reverse().forEach((entry) => {
          const card = document.createElement("div");
          card.className = "item-card";
          card.style.marginBottom = "10px";
          card.innerHTML = `
            <div style="display:flex;justify-content:space-between;align-items:center;">
              <div class="item-card-title">${entry.speaker || "旁白 / 莉莉安娜"}</div>
              ${entry.voice ? `<button class="ctrl-btn" onclick="event.stopPropagation();Engine.replayVoice('${entry.voice}')">🔊 重播语音 (${entry.voice})</button>` : ""}
            </div>
            <div class="item-card-desc">${entry.text}</div>
          `;
          bodyEl.appendChild(card);
        });
      }
    } else if (type === "status") {
      titleEl.textContent = "角色好感度与路线状态 (Character Affection & Status)";
      const charas = [
        { name: "但丁·法尔宗 (Dante)", key: "好感度_ダンテ", max: 12 },
        { name: "吉尔伯特·烈福 (Gilbert)", key: "好感度_ギルバート", max: 12 },
        { name: "杨 (Yang)", key: "好感度_楊", max: 12 },
        { name: "尼古拉·法兰捷斯卡 (Nicola)", key: "好感度_ニコラ", max: 12 },
        { name: "奥罗克 (Orlock)", key: "好感度_オルロック", max: 12 },
        { name: "亨利 (Henri)", key: "好感度_アンリ", max: 10 },
        { name: "路线副参数 (Sub Param)", key: "サブパラメータ", max: 10 }
      ];
      charas.forEach((c) => {
        const val = Number(state.flags[c.key] || 0);
        const pct = Math.min(100, Math.round((val / c.max) * 100));
        const row = document.createElement("div");
        row.className = "affection-row";
        row.innerHTML = `
          <div class="affection-name">${c.name}</div>
          <div class="affection-bar-bg"><div class="affection-bar-fill" style="width:${pct}%"></div></div>
          <div style="width:90px;text-align:right;color:var(--gold-light);font-weight:600;">${val} / ${c.max}</div>
          <button class="ctrl-btn" onclick="Engine.adjustFlag('${c.key}', 1)">+1</button>
        `;
        bodyEl.appendChild(row);
      });
    } else if (type === "chapter") {
      titleEl.textContent = "全章节与个人线直达 (Chapter & Route Select - All Unlocked)";
      renderChapterModal(bodyEl);
    } else if (type === "dict") {
      titleEl.textContent = "布鲁罗纳术语词典 (Burlone Dictionary - 89 Entries)";
      const grid = document.createElement("div");
      grid.className = "grid-2";
      DB.dictionary.forEach((d) => {
        const card = document.createElement("div");
        card.className = "item-card";
        card.innerHTML = `
          <div class="item-card-title">#${d.id} ${d.title}</div>
          <div class="item-card-desc">${d.text}</div>
        `;
        grid.appendChild(card);
      });
      bodyEl.appendChild(grid);
    }
  }

  function renderChapterModal(container) {
    const tabBar = document.createElement("div");
    tabBar.className = "route-tab-bar";
    const listArea = document.createElement("div");
    listArea.className = "grid-2";

    DB.routeScenarios.forEach((groupObj, idx) => {
      const tab = document.createElement("button");
      tab.className = "route-tab" + (idx === 0 ? " active" : "");
      tab.textContent = groupObj.group;
      tab.onclick = () => {
        Array.from(tabBar.children).forEach(b => b.classList.remove("active"));
        tab.classList.add("active");
        renderGroupItems(groupObj.items);
      };
      tabBar.appendChild(tab);
    });

    function renderGroupItems(items) {
      listArea.innerHTML = "";
      items.forEach((it) => {
        const chapMeta = DB.chapterList.find(c => c.title && it.title.includes(c.title));
        const card = document.createElement("div");
        card.className = "item-card";
        card.onclick = () => jumpToScenario(it.file, it.sure);
        card.innerHTML = `
          <div class="item-card-title">${it.title}</div>
          <div class="item-card-desc">${chapMeta ? chapMeta.synopsis : `点击直接从 scenario/${it.file}.iet (${it.sure}) 开始游玩`}</div>
        `;
        listArea.appendChild(card);
      });
    }

    container.appendChild(tabBar);
    container.appendChild(listArea);
    renderGroupItems(DB.routeScenarios[0].items);
  }

  function closeModal() {
    document.getElementById("modal-container").style.display = "none";
  }

  function saveToSlot(slot) {
    const snap = createSaveSnapshot();
    localStorage.setItem(`piofiore_save_${slot}`, JSON.stringify(snap));
    openModal("save");
  }

  function loadFromSlot(slot) {
    const raw = localStorage.getItem(`piofiore_save_${slot}`);
    if (raw) loadSaveData(JSON.parse(raw));
  }

  function adjustFlag(key, delta) {
    state.flags[key] = (state.flags[key] || 0) + delta;
    openModal("status");
  }

  // Assets Folder Mounting (Supports both Native iOS WKScriptMessageHandler & Web Folder Input)
  function openAssetsPicker() {
    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.nativeBridge) {
      window.webkit.messageHandlers.nativeBridge.postMessage({ action: "pickAssetsFolder" });
    } else {
      document.getElementById("web-folder-input").click();
    }
  }

  function onWebFolderSelected(event) {
    const files = event.target.files;
    if (!files || files.length === 0) return;
    localFileMap.clear();
    imageCache.clear();
    parsedScripts = {};

    for (const f of files) {
      let rel = (f.webkitRelativePath || f.name).replace(/\\/g, "/");
      const idx = rel.indexOf("assets/");
      if (idx !== -1) {
        rel = rel.substring(idx + 7);
      } else {
        // If user selected the `assets` folder itself, strip its root folder name
        const parts = rel.split("/");
        if (parts.length > 1 && ["scenario", "image", "sound", "movie", "system", "fonts"].includes(parts[1])) {
          rel = parts.slice(1).join("/");
        }
      }
      localFileMap.set(rel.toLowerCase(), f);
    }

    document.getElementById("hud-asset-badge").textContent = `已加载本地资源 (${localFileMap.size} 项)`;
    document.getElementById("title-asset-status").innerHTML = `
      <strong style="color:#7ef29a;">✅ 本地 assets 文件夹挂载成功！</strong><br>
      共索引 <strong>${localFileMap.size}</strong> 个本地游戏资源文件（含剧本、立绘、CG、BGM 与语音）。现在点击下方「开始新游戏」或「章节与路线选择」即可体验完整原生音画！
    `;
  }

  window.onNativeAssetsStatus = function(status) {
    if (status && status.mounted) {
      nativeAssetsMounted = true;
      imageCache.clear();
      parsedScripts = {};
      document.getElementById("hud-asset-badge").textContent = `已挂载原生资源 (${status.mountedPath})`;
      document.getElementById("title-asset-status").innerHTML = `
        <strong style="color:#7ef29a;">✅ iOS 原生本地资源目录 (${status.mountedPath}) 已就绪！</strong><br>
        剧本库：${status.hasScenario ? "已就绪" : "检测中"} ｜ 背景CG：${status.hasBack ? "已就绪" : "检测中"} ｜ 角色立绘：${status.hasChara ? "已就绪" : "检测中"} ｜ 语音包：${status.hasVoice ? "已就绪" : "检测中"}
      `;
    }
  };

  window.addEventListener("DOMContentLoaded", () => {
    resizeStage();
    if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.nativeBridge) {
      window.webkit.messageHandlers.nativeBridge.postMessage({ action: "checkStatus" });
    }
  });

  return {
    startNewGame,
    continueGame,
    onStageClick,
    toggleAuto,
    toggleSkip,
    quickSave,
    quickLoad,
    openModal,
    closeModal,
    saveToSlot,
    loadFromSlot,
    adjustFlag,
    replayVoice: playVoice,
    triggerMsScene,
    skipMovie,
    showTitleScreen,
    openAssetsPicker,
    onWebFolderSelected
  };
})();
