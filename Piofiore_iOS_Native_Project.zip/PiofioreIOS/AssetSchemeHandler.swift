import Foundation
import WebKit
import UniformTypeIdentifiers

/// Handles `piofiore://assets/...` URL requests inside WKWebView, reading directly from:
/// 1. User-selected external `assets` folder (via Security-Scoped Bookmark in iOS Files app)
/// 2. App's `Documents/assets` or `Documents` folder (via iOS Files app -> On My iPhone -> 虔诚之花的晚钟)
/// 3. App Bundle's `Engine` folder
class AssetSchemeHandler: NSObject, WKURLSchemeHandler {

    static let shared = AssetSchemeHandler()
    private let bookmarkKey = "PiofioreAssetsFolderBookmark"
    private var mountedFolderURL: URL?

    override init() {
        super.init()
        restoreMountedFolderBookmark()
        ensureDocumentsMarkerFile()
    }

    /// Creates a README.txt inside the app's Documents folder so the app folder immediately
    /// appears inside iPhone's "Files (文件)" -> "On My iPhone (我的 iPhone)" -> "虔诚之花的晚钟"
    private func ensureDocumentsMarkerFile() {
        guard let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else { return }
        let marker = docs.appendingPathComponent("请将解压后的assets文件夹放在此处.txt")
        if !FileManager.default.fileExists(atPath: marker.path) {
            let info = """
            【虔诚之花的晚钟 -ricordo- iOS 原生版】
            使用方法（二选一）：
            1. 直接在 iOS「文件」App 中，将解压出来的 `assets` 文件夹（包含 scenario、image、sound、movie、system 等子目录）移动到本目录（我的 iPhone -> 虔诚之花的晚钟）下；
            2. 或者在游戏启动界面点击「📂 选择手机中的 assets 文件夹」，直接选中你手机里现有的 `assets` 文件夹即可免拷贝直接游玩！
            """
            try? info.write(to: marker, atomically: true, encoding: .utf8)
        }
    }

    func saveMountedFolderURL(_ url: URL) {
        let accessed = url.startAccessingSecurityScopedResource()
        defer { if accessed { url.stopAccessingSecurityScopedResource() } }
        if let data = try? url.bookmarkData(options: .minimalBookmark, includingResourceValuesForKeys: nil, relativeTo: nil) {
            UserDefaults.standard.set(data, forKey: bookmarkKey)
        }
        self.mountedFolderURL = url
    }

    private func restoreMountedFolderBookmark() {
        guard let data = UserDefaults.standard.data(forKey: bookmarkKey) else { return }
        var isStale = false
        if let url = try? URL(resolvingBookmarkData: data, bookmarkDataIsStale: &isStale) {
            _ = url.startAccessingSecurityScopedResource()
            self.mountedFolderURL = url
        }
    }

    /// Resolves a relative asset path (e.g. `scenario/100.iet` or `image/back/bg_15c.jpg`)
    func resolveAssetFile(relativePath: String) -> URL? {
        let cleanRel = relativePath.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        let fm = FileManager.default

        var candidateRoots: [URL] = []
        if let mounted = mountedFolderURL {
            candidateRoots.append(mounted)
            candidateRoots.append(mounted.appendingPathComponent("assets"))
        }
        if let docs = fm.urls(for: .documentDirectory, in: .userDomainMask).first {
            candidateRoots.append(docs.appendingPathComponent("assets"))
            candidateRoots.append(docs.appendingPathComponent("虔诚之花的晚钟/assets"))
            candidateRoots.append(docs)
        }
        if let bundleAssets = Bundle.main.resourceURL?.appendingPathComponent("assets") {
            candidateRoots.append(bundleAssets)
        }
        if let bundleEngineAssets = Bundle.main.resourceURL?.appendingPathComponent("Engine/assets") {
            candidateRoots.append(bundleEngineAssets)
        }
        if let bundleEngine = Bundle.main.resourceURL?.appendingPathComponent("Engine") {
            candidateRoots.append(bundleEngine)
        }
        if let bundleRoot = Bundle.main.resourceURL {
            candidateRoots.append(bundleRoot)
        }

        for root in candidateRoots {
            let directURL = root.appendingPathComponent(cleanRel)
            if fm.fileExists(atPath: directURL.path) {
                return directURL
            }
            // Case-insensitive fallback for subpaths likePrologue.mp4 vs prologue.mp4
            let parentDir = directURL.deletingLastPathComponent()
            let targetName = directURL.lastPathComponent.lowercased()
            if let items = try? fm.contentsOfDirectory(atPath: parentDir.path) {
                if let match = items.first(where: { $0.lowercased() == targetName }) {
                    return parentDir.appendingPathComponent(match)
                }
            }
        }
        return nil
    }

    func checkAssetsStatus() -> [String: Any] {
        let has100 = resolveAssetFile(relativePath: "scenario/100.iet") != nil
        let has150 = resolveAssetFile(relativePath: "scenario/150.iet") != nil
        let hasBack = resolveAssetFile(relativePath: "image/back/bg_01a.jpg") != nil || resolveAssetFile(relativePath: "image/back/BAD_END.jpg") != nil
        let hasChara = resolveAssetFile(relativePath: "image/chara/b-dan_a10.png") != nil || resolveAssetFile(relativePath: "image/chara/b-dan_a100a.png") != nil
        let hasVoice = resolveAssetFile(relativePath: "sound/voice_ogg/010001.ogg") != nil
        return [
            "mounted": hasBack || hasChara || hasVoice,
            "hasScenario": has100 && has150,
            "hasBack": hasBack,
            "hasChara": hasChara,
            "hasVoice": hasVoice,
            "mountedPath": mountedFolderURL?.lastPathComponent ?? "Documents/assets"
        ]
    }

    func webView(_ webView: WKWebView, start urlSchemeTask: WKURLSchemeTask) {
        guard let reqURL = urlSchemeTask.request.url else {
            urlSchemeTask.didFailWithError(URLError(.badURL))
            return
        }

        let host = reqURL.host ?? ""
        let rawPath = reqURL.path.trimmingCharacters(in: CharacterSet(charactersIn: "/"))

        // Special status endpoint: piofiore://status/check
        if host == "status" {
            let statusDict = checkAssetsStatus()
            let jsonData = (try? JSONSerialization.data(withJSONObject: statusDict)) ?? Data("{}".utf8)
            let resp = HTTPURLResponse(
                url: reqURL,
                statusCode: 200,
                httpVersion: "HTTP/1.1",
                headerFields: [
                    "Content-Type": "application/json; charset=utf-8",
                    "Access-Control-Allow-Origin": "*"
                ]
            )!
            urlSchemeTask.didReceive(resp)
            urlSchemeTask.didReceive(jsonData)
            urlSchemeTask.didFinish()
            return
        }

        // Engine bundle files: piofiore://app/index.html, piofiore://app/game_data.js, etc.
        if host == "app" {
            let fileName = rawPath.isEmpty ? "index.html" : rawPath
            if let bundleURL = Bundle.main.url(forResource: fileName, withExtension: nil, subdirectory: "Engine")
                ?? Bundle.main.url(forResource: (fileName as NSString).deletingPathExtension, withExtension: (fileName as NSString).pathExtension) {
                serveFile(url: bundleURL, reqURL: reqURL, task: urlSchemeTask)
                return
            }
        }

        // Game asset files: piofiore://assets/scenario/100.iet, piofiore://assets/image/back/bg_01a.jpg, etc.
        if let fileURL = resolveAssetFile(relativePath: rawPath) {
            serveFile(url: fileURL, reqURL: reqURL, task: urlSchemeTask)
            return
        }

        let notFoundResp = HTTPURLResponse(
            url: reqURL,
            statusCode: 404,
            httpVersion: "HTTP/1.1",
            headerFields: ["Access-Control-Allow-Origin": "*"]
        )!
        urlSchemeTask.didReceive(notFoundResp)
        urlSchemeTask.didReceive(Data())
        urlSchemeTask.didFinish()
    }

    func webView(_ webView: WKWebView, stop urlSchemeTask: WKURLSchemeTask) {
        // No-op
    }

    private func serveFile(url: URL, reqURL: URL, task: WKURLSchemeTask) {
        let accessed = url.startAccessingSecurityScopedResource()
        defer { if accessed { url.stopAccessingSecurityScopedResource() } }

        guard let data = try? Data(contentsOf: url) else {
            task.didFailWithError(URLError(.cannotOpenFile))
            return
        }

        let ext = url.pathExtension.lowercased()

        // Automatic native Ogg Vorbis -> 16-bit PCM WAV transcoding for 100% iOS audio compatibility!
        if ext == "ogg" {
            var wavLen: Int = 0
            let wavPtr: UnsafeMutablePointer<UInt8>? = data.withUnsafeBytes { rawBuf in
                guard let base = rawBuf.baseAddress?.assumingMemoryBound(to: UInt8.self) else { return nil }
                return piofiore_decode_ogg_to_wav(base, data.count, &wavLen)
            }
            if let ptr = wavPtr, wavLen > 0 {
                let wavData = Data(bytesNoCopy: ptr, count: wavLen, deallocator: .free)
                let resp = HTTPURLResponse(
                    url: reqURL,
                    statusCode: 200,
                    httpVersion: "HTTP/1.1",
                    headerFields: [
                        "Content-Type": "audio/wav",
                        "Content-Length": "\(wavData.count)",
                        "Access-Control-Allow-Origin": "*"
                    ]
                )!
                task.didReceive(resp)
                task.didReceive(wavData)
                task.didFinish()
                return
            }
        }

        let mimeType: String
        switch ext {
        case "html": mimeType = "text/html; charset=utf-8"
        case "js":   mimeType = "application/javascript; charset=utf-8"
        case "css":  mimeType = "text/css; charset=utf-8"
        case "iet", "lua", "ini": mimeType = "text/plain; charset=utf-8"
        case "png":  mimeType = "image/png"
        case "jpg", "jpeg": mimeType = "image/jpeg"
        case "ogg":  mimeType = "audio/ogg"
        case "mp3":  mimeType = "audio/mpeg"
        case "wav":  mimeType = "audio/wav"
        case "mp4":  mimeType = "video/mp4"
        case "ttf":  mimeType = "font/ttf"
        case "otf":  mimeType = "font/otf"
        default:     mimeType = "application/octet-stream"
        }

        let resp = HTTPURLResponse(
            url: reqURL,
            statusCode: 200,
            httpVersion: "HTTP/1.1",
            headerFields: [
                "Content-Type": mimeType,
                "Content-Length": "\(data.count)",
                "Access-Control-Allow-Origin": "*",
                "Accept-Ranges": "bytes"
            ]
        )!
        task.didReceive(resp)
        task.didReceive(data)
        task.didFinish()
    }
}
