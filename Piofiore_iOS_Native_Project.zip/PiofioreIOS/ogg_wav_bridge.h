#ifndef OGG_WAV_BRIDGE_H
#define OGG_WAV_BRIDGE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

// Converts an Ogg Vorbis buffer in memory into a standard 16-bit PCM WAV buffer.
// Returns a malloc'd buffer and sets *out_wav_len, or returns NULL if stb_vorbis is not compiled in or decoding fails.
// Caller must free() the returned buffer.
uint8_t* piofiore_decode_ogg_to_wav(const uint8_t* ogg_data, size_t ogg_len, size_t* out_wav_len);

#ifdef __cplusplus
}
#endif

#endif
